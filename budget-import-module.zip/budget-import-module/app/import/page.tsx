import { TransactionImport } from '@/app/components/transaction-import'

export default function ImportPage() {
  return (
    <div className="container mx-auto py-10">
      <TransactionImport />
    </div>
  )
}

